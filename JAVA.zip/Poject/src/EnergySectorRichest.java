public class EnergySectorRichest {
    private String name;
    private String company;
    private double netWorth;

    public EnergySectorRichest(String name, String company, double netWorth) {
        this.name = name;
        this.company = company;
        this.netWorth = netWorth;
    }

    public String getName() {
        return name;
    }

    public String getCompany() {
        return company;
    }

    public double getNetWorth() {
        return netWorth;
    }

    @Override
    public String toString() {
        return "EnergySectorRichest{" +
                "name='" + name + '\'' +
                ", company='" + company + '\'' +
                ", netWorth=" + netWorth +
                '}';
    }
}