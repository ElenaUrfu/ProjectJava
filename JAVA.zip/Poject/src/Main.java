import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        // Read data from CSV
        List<ForbesPerson> persons = readForbesData("C:\\Users\\deads\\OneDrive\\Рабочий стол\\проект Java\\forbes.csv");

        // Database operations
        try {
            SQL sql = new SQL("C:\\Users\\deads\\OneDrive\\Рабочий стол\\проект Java\\Library\\forbes.db");

            // Create table and insert data
            sql.createTable();
            sql.insertData(persons);

            // Task 1: Display country capital chart
            List<CountryCapitalChartData> chartData = sql.getCountryCapitalData();
            Chart.displayCountryCapitalChart(chartData);

            // Task 2: Find youngest French billionaire with >10B net worth
            ForbesPerson youngestFrench = sql.getYoungestFrenchBillionaire();
            System.out.println("\nYoungest French billionaire with >10B:");
            System.out.println("Name: " + youngestFrench.getName());
            System.out.println("Age: " + youngestFrench.getAge());
            System.out.println("Net Worth: " + youngestFrench.getNetWorth() + "B");
            System.out.println("Source: " + youngestFrench.getSource());

            // Task 3: Find richest in Energy sector from US
            EnergySectorRichest richestInEnergy = sql.getRichestInEnergySectorFromUS();
            System.out.println("\nRichest in Energy sector from US:");
            System.out.println("Name: " + richestInEnergy.getName());
            System.out.println("Company: " + richestInEnergy.getCompany());
            System.out.println("Net Worth: " + richestInEnergy.getNetWorth() + "B");

            // Close connection
            sql.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static List<ForbesPerson> readForbesData(String filename) {
        List<ForbesPerson> persons = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(new FileReader(filename))) {
            // Skip header line
            br.readLine();

            String line;
            while ((line = br.readLine()) != null) {
                String[] values = line.split(",");

                // Handle cases where name or source might contain commas
                if (values.length > 7) {
                    // Simple approach - in real app would need more robust parsing
                    values = line.split(",(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)", -1);
                }

                int rank = Integer.parseInt(values[0].trim());
                String name = values[1].trim();
                double netWorth = Double.parseDouble(values[2].trim());
                int age = Integer.parseInt(values[3].trim());
                String country = values[4].trim();
                String source = values[5].replace("\"", "").trim();
                String industry = values[6].replace("\"", "").trim();

                persons.add(new ForbesPerson(rank, name, netWorth, age, country, source, industry));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return persons;
    }
}