public class CountryCapitalChartData {
    private String country;
    private double totalCapital;

    public CountryCapitalChartData(String country, double totalCapital) {
        this.country = country;
        this.totalCapital = totalCapital;
    }

    public String getCountry() {
        return country;
    }

    public double getTotalCapital() {
        return totalCapital;
    }

    @Override
    public String toString() {
        return "CountryCapitalChartData{" +
                "country='" + country + '\'' +
                ", totalCapital=" + totalCapital +
                '}';
    }
}