import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.chart.axis.CategoryAxis;

import javax.swing.*;
import java.awt.*;
import java.util.List;

public class Chart {
    public static void displayCountryCapitalChart(List<CountryCapitalChartData> data) {
        // Создаем датасет
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        for (CountryCapitalChartData item : data) {
            dataset.addValue(item.getTotalCapital(), "Total Capital", item.getCountry());
        }

        // Создаем график
        JFreeChart barChart = ChartFactory.createBarChart(
                "Country vs Total Capital",
                "Country",
                "Total Capital (in billions)",
                dataset,
                PlotOrientation.VERTICAL,
                true, true, false);

        // Настраиваем ось X для отображения длинных названий
        CategoryAxis domainAxis = barChart.getCategoryPlot().getDomainAxis();
        domainAxis.setCategoryLabelPositions(
                org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions(Math.PI / 6.0)); // наклон 30 градусов

        // Создаем панель для отображения графика
        ChartPanel chartPanel = new ChartPanel(barChart);
        chartPanel.setPreferredSize(new Dimension(800, 600));

        // Создаем окно
        JFrame frame = new JFrame("Country Capital Chart");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.add(chartPanel);
        frame.pack();
        frame.setLocationRelativeTo(null); // по центру экрана
        frame.setVisible(true);
    }
}