import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class SQL {
    private Connection connection;

    public SQL(String dbPath) throws SQLException {
        this.connection = DriverManager.getConnection("jdbc:sqlite:" + dbPath);
    }

    public void createTable() throws SQLException {
        String sql = "CREATE TABLE IF NOT EXISTS forbes (" +
                "rank INTEGER PRIMARY KEY, " +
                "name TEXT, " +
                "networth REAL, " +
                "age INTEGER, " +
                "country TEXT, " +
                "source TEXT, " +
                "industry TEXT)";

        try (Statement stmt = connection.createStatement()) {
            stmt.execute(sql);
        }
    }

    public void insertData(List<ForbesPerson> persons) throws SQLException {
        String sql = "INSERT INTO forbes (rank, name, networth, age, country, source, industry) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?)";

        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            for (ForbesPerson person : persons) {
                pstmt.setInt(1, person.getRank());
                pstmt.setString(2, person.getName());
                pstmt.setDouble(3, person.getNetWorth());
                pstmt.setInt(4, person.getAge());
                pstmt.setString(5, person.getCountry());
                pstmt.setString(6, person.getSource());
                pstmt.setString(7, person.getIndustry());
                pstmt.executeUpdate();
            }
        }
    }

    public List<CountryCapitalChartData> getCountryCapitalData() throws SQLException {
        List<CountryCapitalChartData> data = new ArrayList<>();
        String sql = "SELECT country, SUM(networth) as totalCapital FROM forbes GROUP BY country";

        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                data.add(new CountryCapitalChartData(
                        rs.getString("country"),
                        rs.getDouble("totalCapital")
                ));
            }
        }
        return data;
    }

    public ForbesPerson getYoungestFrenchBillionaire() throws SQLException {
        String sql = "SELECT * FROM forbes WHERE country = 'France' AND networth > 10 " +
                "ORDER BY age ASC LIMIT 1";

        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            if (rs.next()) {
                return new ForbesPerson(
                        rs.getInt("rank"),
                        rs.getString("name"),
                        rs.getDouble("networth"),
                        rs.getInt("age"),
                        rs.getString("country"),
                        rs.getString("source"),
                        rs.getString("industry")
                );
            }
        }
        return null;
    }

    public EnergySectorRichest getRichestInEnergySectorFromUS() throws SQLException {
        String sql = "SELECT name, source as company, networth FROM forbes " +
                "WHERE country = 'United States' AND industry = 'Energy' " +
                "ORDER BY networth DESC LIMIT 1";

        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            if (rs.next()) {
                return new EnergySectorRichest(
                        rs.getString("name"),
                        rs.getString("company"),
                        rs.getDouble("networth")
                );
            }
        }
        return null;
    }

    public void close() throws SQLException {
        if (connection != null) {
            connection.close();
        }
    }
}